export class User {
    firstName : string 
    lastName : string
    constructor( public userName : string, public password : string ) {  }
}