package io.cts.productinfoservice.resourse;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.cts.productinfoservice.model.Product;

@RestController
@RequestMapping("/product")
public class ProductInfoResource {

	public static List<Product> productList;
	static {
		productList = Arrays.asList(
				new Product("product1", "1000.00","10/10/2020"), 
				new Product("product2", "500.00","5/5/2020"),
				new Product("product3", "1500.00","10/12/2020")
				);
	}

	public ProductInfoResource() {
		System.out.println("Product Info Service **************");
	}

	@RequestMapping("/{productName}")

	public Product getCatalog(@PathVariable("productName") String productName) {
		for (Product product : productList) {
			System.out.println(product.getProductName() + "" + productName);
			if(product.getProductName().equals(productName)) {
				System.out.println(product);
				return product;
			}
		}
		return null;
	}
}
