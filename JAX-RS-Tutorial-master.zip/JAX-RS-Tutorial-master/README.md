# JAX-RS Tutorial
This is a project walkthrough the practice of the course - [Developing REST APIs with JAX-RS](https://javabrains.io/courses/javaee_jaxrs/) by [Java Brains](https://javabrains.io/).