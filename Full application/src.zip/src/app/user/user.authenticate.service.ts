import {Injectable} from '@angular/core';
import {User} from './user.model'

@Injectable()
export class UserAuthenticateService {
  user : User;

  login(loginForm){
      this.user = {
        password : loginForm.password,
        userName: loginForm.userName,
        firstName: 'CTS',
        lastName: 'Angular'
        }
      }

      updateUser(first : string, last : string){
        this.user = {
          password : 'test',
          userName: 'test',
          firstName: first,
          lastName: last
          }
        }
        
      isAuthenticated() {
        console.log('is called')
        return !!this.user
      }
}
