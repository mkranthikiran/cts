import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TestComponent } from './test.component';
import {UserLoginComponent} from './user.login.component'
import { UserProfileComponent } from './user.profile.component';
const routes: Routes = [
  {path:'login', component : UserLoginComponent},
  {path:'profile', component : UserProfileComponent},
  {path:'test', component : TestComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
