import React, { Component } from 'react'

class ClassClickstatechange extends Component {

    constructor(props) {
        super(props)
        this.state =  { message : 'Welcome User'}
        // this.clickHandler = this.clickHandler.bind(this)
        console.log(this.state.message);
    }

    // clickHandler = () => {
    //     this.setState({
    //         message: 'Thanks For Registering'
    //     })
    //   console.log("Button is clicked");
    // }

    clickHandler() {
        this.setState({
            message: 'Thanks For Registering'
        })
      console.log("Button is clicked");
    }

  render() {
     return (
      <div>
        <div>{this.state.message}</div>
        {/* <button onClick={this.clickHandler.bind(this)}>Click Me</button> */}
        {/* <button onClick={() => this.clickHandler()}>Click Me</button> */}
        {/* <button onClick={this.clickHandler}>Click Me</button> */}
      </div>
    )
  }
}

export default ClassClickstatechange