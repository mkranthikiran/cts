package com.cognizant.message;

import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cognizant.message.model.Message;
import com.cognizant.message.service.MessageService;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("messages")
public class MessageResource {

	MessageService service = new MessageService();
   
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Message> getMessages() {
        return service.getMessages();
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Message getMessage(@PathParam("id") long meesageId) {
    	System.out.println(service.getMessageByID(meesageId));
        return service.getMessageByID(meesageId);
    }
    
    
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Message deleteMessage(@PathParam("id") long meesageId) {
    	System.out.println(service.getMessages());
    	
        return service.deleteMessageByID(meesageId);
    }
    
    @PUT
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Message updateMessage(@PathParam("id") long meesageId ,Message message) {
    	System.out.println(service.getMessages());
        return service.updateMessageByID(meesageId,message);
    }
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Message updateMessage(Message message) {
    	System.out.println(service.getMessages());
        return service.insertMessageByID(message);
    }
}
