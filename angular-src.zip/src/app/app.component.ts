import { Component } from '@angular/core';

@Component({
  selector: 'course',
  template: `<nav-bar></nav-bar>
             <router-outlet></router-outlet>
            `,
  styleUrls: ['./app.component.css']
})
export class CourseComponent {
 course = 
      { id : 1,
        courseName : 'Angular 8',
        price : 2500
      }
      
      
  add(i,j){
    return i*j;
  }
}
