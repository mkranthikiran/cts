package com.cognizant.message.service;

import java.util.Collection;
import java.util.HashMap;

import com.cognizant.message.model.Message;

public class MessageService {

	static HashMap<Long,Message> messages= new HashMap<>();
	
	
	static {
		Message message1 = new Message(100,"First Message","Author1");
		Message message2 = new Message(101,"Second Message","Author2");
		messages.put(100l, message1);
		messages.put(101l, message2);
	  }
	
	public Collection<Message> getMessages() {
		return messages.values();
	}
	
	public Message getMessageByID(long id) {
		System.out.println("id = " + id);
		return messages.get(id);
	}
	
	public Message deleteMessageByID(long id) {
		System.out.println("id = " + id);
		return messages.remove(id);
	}

	public Message updateMessageByID(long meesageId, Message message) {
		message.setId(meesageId);
		messages.put(meesageId, message);
		return message;
	}

	public Message insertMessageByID(Message message) {
		messages.put(message.getId(), message);
		return message;
	}
}
