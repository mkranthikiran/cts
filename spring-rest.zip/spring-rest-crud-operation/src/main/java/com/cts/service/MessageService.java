package com.cts.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.model.Message;
import com.cts.repository.MessageRepository;

//defining the business logic
@Service
public class MessageService {
	@Autowired
	MessageRepository messageRepository;

	// getting all messages record by using the method findaAll() of CrudRepository
	public List<Message> getAllMessage() {
		List<Message> messages = new ArrayList<Message>();
		messageRepository.findAll().forEach(messages1 -> messages.add(messages1));
		return messages;
	}

	// getting a specific record by using the method findById() of CrudRepository
	public Message getMessageById(long id) {
		return messageRepository.findById(id).get();
	}

	// saving a specific record by using the method save() of CrudRepository
	public void saveOrUpdate(Message messages) {
		messageRepository.save(messages);
	}

	// deleting a specific record by using the method deleteById() of CrudRepository
	public void delete(long id) {
		messageRepository.deleteById(id);
	}

	// updating a record
	public void update(Message messages, long messageid) {
		messageRepository.save(messages);
	}
}