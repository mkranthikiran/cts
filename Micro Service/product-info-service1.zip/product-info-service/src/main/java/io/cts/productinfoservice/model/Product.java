package io.cts.productinfoservice.model;

public class Product {

	private String productName;
	private String price;
	private String date;

	public Product() {
		// TODO Auto-generated constructor stub
	}

	
	public Product(String productName, String price, String date) {
		super();
		this.productName = productName;
		this.price = price;
		this.date = date;
	}


	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	@Override
	public String toString() {
		return "Product [productName=" + productName + ", price=" + price + ", date=" + date + "]";
	}



}
