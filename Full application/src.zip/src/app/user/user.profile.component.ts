import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {UserAuthenticateService} from './user.authenticate.service'
@Component({
  templateUrl: `./user.profile.component.html`,
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class UserProfileComponent implements OnInit {
  profileForm: FormGroup;
   constructor(private router: Router,private userauthenticateService : UserAuthenticateService) { }

  ngOnInit() {
    let firstName = new FormControl(this.userauthenticateService.user.firstName,[Validators.required,Validators.minLength(4)]);
    let lastName = new FormControl(this.userauthenticateService.user.lastName,Validators.required);
    this.profileForm = new FormGroup({
      firstName: firstName,
      lastName: lastName
    })
  }

  saveUser(profileForm){
      this.userauthenticateService.updateUser(profileForm.firstName,profileForm.lastName)
  }
cancel()
{ this.router.navigate(['/allcourses']) }
}
//this.authenticteService.currentUser.firstName, Validators.required
//this.authenticteService.currentUser.lastName, Validators.required