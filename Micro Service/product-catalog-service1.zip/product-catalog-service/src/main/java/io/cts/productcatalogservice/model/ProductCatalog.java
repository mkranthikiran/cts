package io.cts.productcatalogservice.model;

public class ProductCatalog {
	
	private String productName;
	private String price;
	private String date;
	private int rating;

	public ProductCatalog() {
		// TODO Auto-generated constructor stub
	}

	public ProductCatalog(String productName, String price, int rating,String date) {
		super();
		this.productName = productName;
		this.price = price;
		this.rating = rating;
		this.date = date;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "ProductCatalog [productName=" + productName + ", price=" + price + ", rating=" + rating + "]";
	}

}
