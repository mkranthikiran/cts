import logo from './logo.svg';
import './App.css';
import Greet from "./appcomponents/Greet";
import Welcome from './appcomponents/Welcome';
import Hello from './appcomponents/Hello';
import AppChild from './appcomponents/AppChild'
import Message from './appcomponents/Message'
import IFEx from './appcomponents/IFEx';
import SwitchEx from './appcomponents/SwithEx';
import PersonList from './appcomponents/PersonList';
import  FunctionClick from './appcomponents/FunctionClick'
import ClassClick from './appcomponents/ClassClick';
import ClassClickstatechange from './appcomponents/ClassClickstatechange';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <ClassClickstatechange/>
        {/* <ClassClick/> */}
        {/* <FunctionClick /> */}
        {/* <PersonList/> */}
        {/* <SwitchEx/> */}
        {/* <IFEx/> */}
        {/*  <Greet batch="INTADM20AJ017" daypart="Good Morning"/>
           <Message/> 
         <AppChild color='red'/>
        <Greet batch="INTADM20AJ017" daypart="Good Morning">
            <p> I am child for Greet component</p>
         </Greet>
          {  <Greet batch="INTADM20AJ017" daypart="Good Afternoon"/> }
         <Greet batch="INTADM20AJ017" daypart="Good Evening"/> 
         Hello World
         <Welcome  batch="INTADM20AJ017" daypart="Good Morning"/>

         <Hello/>*/}

      </header>
    </div>
  );
}

export default App;
