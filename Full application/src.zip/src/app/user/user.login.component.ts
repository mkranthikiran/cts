import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAuthenticateService } from './user.authenticate.service'
import { User } from './user.model';

@Component({
  templateUrl: `./user.login.component.html`,
  styles: ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class UserLoginComponent {

  constructor(private router: Router, private authenticateService: UserAuthenticateService) { }
model = new User("user1","user1");

  login(loginForm) {
    this.authenticateService.login(loginForm);
    this.router.navigate(['/user/profile'])
  }
  cancel() { this.router.navigate(['/allcourses']) }

}


