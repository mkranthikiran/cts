import React, {Component} from 'react';

class AppChild extends Component {

    constructor(props) {
        super(props)
        this.state=  { colorName : props.color}
        console.log(props.color)
      }
    render(){
        return(<div>{this.state.colorName}</div>);
    }
 }
 
 
 export default AppChild