import React, { Component } from 'react';

class IFEx extends Component {

    constructor(props) {
        super(props)
        this.state = { isLoggedIn: true }
     }


    render() {
        // let message
        // if (this.state.isLoggedIn) {
        //     message = <div>Welcome User</div>
        // } else {
        //     message = <div>Please Login!!!</div>
        // }
        // return message
        return this.state.isLoggedIn ?  (<div>Welcome User</div>)  : (<div>Please Login!!!</div> )
    }
}

export default IFEx