import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {Course} from '../shared/course.model'
import {CourseService} from '../shared/course.service'

@Component({
  selector: 'course-details',
  templateUrl : './fullcoursedetails.component.html',
})

export class FullCourseDetailsComponent implements OnInit {

  course : Course

  constructor(private courseService : CourseService,private activatedRoute : ActivatedRoute,private route : Router){}

  ngOnInit() {
     this.courseService.getCourseById(+this.activatedRoute.snapshot.params['id']).subscribe(data => this.course = data);
  }

  delete(course: Course): void {
     this.courseService.deleteCourse(course).subscribe();
     this.route.navigate(['allcourses']);
  }

  update(): void {
    this.courseService.updateCourse(this.course).subscribe(() => console.log("course updated" + this.course.id));
    this.route.navigate(['allcourses']);
  }
}