import React from 'react'

function SwitchEx() {
    const userType = 'HR';
    
    return (
      <div className="container">
          <h1>React Switch Case Condition Example </h1>
    
          {(() => {
              switch (userType) {
                case 'Admin':
                    return (
                      <div>You are a Admin.</div>
                    )
                case 'Manager':
                    return (
                      <div>You are a Manager.</div>
                    )
                default:
                    return (
                      <div>You are  not a User.</div>
                    )
             }
    
          })()}
      </div>
    );
  }
     
  export default SwitchEx;
  