import { Component } from '@angular/core';
import { JsonService } from './jsonplaceholder.service';

@Component({
  selector: 'json',
  template: ` <div class= "row">
          <div *ngIf="users">
                <div *ngFor="let user of users"   class="col-md-5">
                    <div   class="well hoverwell thumbnail">
                        <div><strong>Name:</strong> {{user?.name }}</div>
                        <div><strong>User Name:</strong> {{user?.username}}</div>
                        <div><strong>Email:</strong> {{user?.email}}</div>
                        <div><strong>phone:</strong> {{user?.phone}}</div>
                        <button class="btn btn-primary" (click) = 'getUser(user.id)' >Get Details</button>
                    </div>
                  </div>
                  </div>
                <div *ngIf="currentUser">
                  <div class="well hoverwell thumbnail">
                  <div><strong>Name:</strong> {{currentUser?.name }}</div>
                  <div><strong>User Name:</strong> {{currentUser?.username}}</div>
                  <div><strong>Email:</strong> {{currentUser?.email}}</div>
                  <div><strong>phone:</strong> {{currentUser?.phone}}</div>    
              </div>
               </div>
               </div>
`,
})
export class JsonComponent {

  users: any;
  currentUser
  constructor(private jsonService: JsonService) {
  }

  ngOnInit() {
    this.jsonService.getAllUsers().subscribe(data => this.users = data);
  }

  getUser(id){
    this.jsonService.getUserById(id).subscribe(data => this.currentUser = data);
  }
}
