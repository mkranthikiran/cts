import React from 'react'

function PersonList() {
    const personNames = ['Sachin','Kohli','Dhoni','Sachin','Ganguly']
    const name =  personNames.map( name => <h2 key={1}>  {name} </h2>)
    const persons = [
        {
          id: 1,
          name: 'Sachin',
          age: 40,
          skill: 'Batsman'
        },
        {
          id: 2,
          name: 'Kohli',
          age: 25,
          skill: 'Batsman'
        },
        {
          id: 3,
          name: 'Dhoni',
          age: 28,
          skill: 'Wicket Keeper'
        }
      ]
      const person =  persons.map( person => <h2 key={person.id}>  {person.name} , {person.age}, {person.skill} </h2>)

     return(
       <div>
                {person}
                {/* <h2>{personNames[1]}</h2>
                <h2>{personNames[2]}</h2>
                <h2>{personNames[3]}</h2> */}
       </div>)	
    }
    
    export default PersonList
    