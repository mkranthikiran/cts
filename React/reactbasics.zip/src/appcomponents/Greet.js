import React from "react";

// function Greet(props) {
//   return (
//     <div><h2>Hello {props.batch} ,Geeting from function component</h2></div>
//   );
// }

const Greet = props => {
  const {batch,daypart} = props
   return (
      <div>
        <h1>Hello, {batch}</h1> 
        <h2>{daypart}</h2>
        {/* <div>
          {props.children}
        </div> */}
      </div>
  )
}

// const Greet = ()  => <h1>Welcome to React. this is the first functional component!!!!</h1>

export default Greet
