import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'allcourse-list',
  template: `
  <div  class="well hoverwell thumbnail" [routerLink]="['/course',tempCourse?.id]" >
  <h2>
              Name : {{tempCourse?.name | uppercase }}
 </h2>
              <div>Date : {{tempCourse?.date | date:'short'}} </div>
              <div>Time : {{tempCourse?.time}} </div>
              <div>Price : {{tempCourse?.price  | currency:"INR"}} </div>
              <div *ngIf="tempCourse?.location">
                <span> Location :{{tempCourse?.location?.trainingRoom}},</span>
                <span> &nbsp;</span>
                <span>{{tempCourse?.location?.building}},{{tempCourse?.location?.city}}</span>
            </div>
            <div *ngIf="tempCourse?.onlineUrl">
                <span> Online URL :{{tempCourse?.onlineUrl}},</span>
            </div>
            <button class="btn btn-primary" (click) = 'callToParent()' >Enroll</button>
</div>
`,
  styles: [`
        .pad-left{margin-left: 10px;}
        .well div {color: #bbb;}`
  ]
})
export class AllCourseListComponent {
  @Input() tempCourse;
  @Output() customevent = new EventEmitter();

  public message = "Hello from Child";

  callToParent() {
    this.customevent.emit(this.tempCourse.name);
    console.log('Button clicked on child component')
  }
}
