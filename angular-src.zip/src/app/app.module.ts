import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { CourseComponent } from './app.component';
import { WelcomeComponent } from './welcome.component '
import { PracticeComponent } from './practice.component';
import { CourseListComponent } from './courses/course-list.component'
import { AllCourseListComponent } from './courses/allcourse-list.component'
import { NavBarComponent } from './navigation/navbar.component'
import { CourseService } from './shared/course.service'
import { FullCourseDetailsComponent } from './courses/fullcoursedetails.component';
import { ErrorComponent } from './error/error.component';
import { CourseRouterActivatorService } from './shared/course.activate.router';

@NgModule({
  declarations: [
    CourseComponent, CourseListComponent, AllCourseListComponent,
    NavBarComponent, WelcomeComponent, PracticeComponent, FullCourseDetailsComponent, ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [CourseService, CourseRouterActivatorService],
  bootstrap: [CourseComponent]
})
export class AppModule { }
