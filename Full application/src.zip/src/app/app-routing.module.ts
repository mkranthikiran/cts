import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CourseListComponent } from './courses/course-list.component';
import { CreateCourseComponent } from './courses/createcourse.component';
import { FullCourseDetailsComponent } from './courses/fullcoursedetails.component';
import { ErrorComponent } from './error/error.component';
import { JsonComponent } from './Jsonplaceholder/json.component';
import { ObservableComponent } from './observableex.component';
import { PracticeComponent } from './practice.component';
import { CourseRouterActivatorService } from './shared/course.activate.router';
import { WelcomeComponent } from './welcome.component ';

const routes: Routes = [
                         {path:'allcourses', component : CourseListComponent},
                         {path:'welcome', component : WelcomeComponent},
                         {path:'practice', component : PracticeComponent},
                         {path:'404', component : ErrorComponent},
                         {path:'courses/new', component : CreateCourseComponent},
                         {path:'course/:id', component : FullCourseDetailsComponent,canActivate:[CourseRouterActivatorService]},
                         {path:'', redirectTo:'/allcourses', pathMatch:'full'},
                         {path:'jsonuser', component : JsonComponent},
                         {path:'observable', component : ObservableComponent},
                         {path:'user', loadChildren:'./user/user.module#UserModule'},
                         {path:'**', redirectTo:'/404', pathMatch:'full'},
                       ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
