import React, { Component } from 'react'


class Welcome extends Component {

    render(){
        return (
            <div><h2>Welcome to class component {this.props.batch} {this.props.daypart}</h2></div>
          );
    }
}

export default Welcome;