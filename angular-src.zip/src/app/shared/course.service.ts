import { Injectable } from "@angular/core";
import { Course } from "./course.model";


@Injectable()
export class CourseService {

     getAllCourses() {
        return courses;
    }

    getCourseById(id: number) {
        for (let course of courses) {
         if (course.id === id)
            return course;
          else
          null;
        }
    }
       // return COURSES.find(course => course.id === id)
}

const courses: Course[] = [
    {
        id: 1,
        name: 'Angular',
        date: new Date('10/10/2010'),
        time: '9:00 am',
        duration: 1,
        price: 1000,
        imageUrl: '/assets/images/angular.png',
        location: {
            trainingRoom: 'Room1',
            building: 'building1',
            city: 'city1'
        }
    },
    {
        id: 2,
        name: 'React',
        date: new Date('4/15/2015'),
        time: '9:00 am',
        price: 950.00,
        imageUrl: '/assets/images/react.png',
        onlineUrl: 'http://www.qwertasasa.com'
    },
    {
        id: 3,
        name: 'Java',
        date: new Date('5/4/2037'),
        time: '9:00 am',
        price: 759.00,
        imageUrl: '/assets/images/java.png',
        location: {
            trainingRoom: 'Room2',
            city: 'city2',
            building: 'building2'
        }
    },
    {
        id: 4,
        name: 'Oracle',
        date: new Date('6/14/2033'),
        time: '8:00 am',
        price: 800.00,
        imageUrl: '/assets/images/oracle.png',
        location: {
            trainingRoom: 'Room1',
            city: 'city1',
            building: 'building1'
        }
    },
    {
        id: 5,
        name: 'Spring',
        date: new Date('12/12/2025'),
        time: '9:00 am',
        price: 400.00,
        imageUrl: '/assets/images/spring.png',
        location: {
            trainingRoom: 'Room2',
            city: 'city2',
            building: 'building1'
        },
    }
]