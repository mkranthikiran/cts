import { Component, OnInit } from '@angular/core';
import {Course} from '../shared/course.model'
import {CourseService} from '../shared/course.service'

@Component({
  selector: 'course-list',
  template: `<div >
  <h1>Upcoming Courses</h1>
  <hr/>
  <div class= "row">
  <div *ngFor="let course of courses"  class="col-md-5">
  <allcourse-list #allcourse (customevent)="callFromChild($event)" [tempCourse]='course'></allcourse-list>
</div>
</div>
</div>
`,
})

export class CourseListComponent implements OnInit {

  courses : Course[]

  constructor(private courseService : CourseService){
    this.courses  =   courseService.getAllCourses();
  }


  ngOnInit() {
  }

  callFromChild(event) {
    console.log("Custom event is fired on child and Notified in parent    "+event )
  }
}
