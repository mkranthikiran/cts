import React, {Component} from 'react';

class Message extends Component {

    constructor(props) {
        super(props)
        this.state =  { message : 'Welcome User'}
        console.log(this.state.message);
    }

    changeMessage(){

        this.setState({
            message: 'Thanks For Registering'
        })
      
        // this.state.message = 'Thanks for Registering'
        // console.log(this.state.message);
    }

    render(){
        return(<div>
            {this.state.message}
            {/* <button onClick={() => this.changeMessage()}>Register</button> */}
            <button onClick={() => this.changeMessage()}>Register</button>
            </div>);
    }
 }
 
 
 export default Message