package io.cts.productcatalogservice.resourse;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.cts.productcatalogservice.model.Product;
import io.cts.productcatalogservice.model.ProductCatalog;
import io.cts.productcatalogservice.model.UserRating;

@RestController
@RequestMapping("/catalog")
public class ProductCatalogResource {
	
	@Autowired
	private RestTemplate restTemplate;

       @RequestMapping("/{userId}")
	    public List<ProductCatalog> getCatalog(@PathVariable("userId") String userId) {


           UserRating userRating = restTemplate.getForObject("http://RATING-SERVICE/ratingsdata/user/" + userId, UserRating.class);

           return userRating.getRatings().stream()
                   .map(rating -> {
                       Product product = restTemplate.getForObject("http://PRODUCT-INFO-SERVICE/product/" + rating.getproductId(), Product.class);
                       return new ProductCatalog(product.getProductName(), product.getPrice(), rating.getRating(),product.getDate());
                   })
                   .collect(Collectors.toList());
    
    	   //  return Collections.singletonList(new ProductCatalog("product1","100.00",4 ));
	    }
}
