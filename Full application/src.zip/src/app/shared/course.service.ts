import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { Course } from "./course.model";
import { catchError, map, tap } from 'rxjs/operators';

@Injectable()
export class CourseService {

  private cousesUrl = 'api/courses';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) {
  }

  getAllCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(this.cousesUrl).pipe(
      catchError(this.handleError<Course[]>('getCourses', []))
    );
  }

  getCourseById(id: number): Observable<Course> {
    const url = `${this.cousesUrl}/${id}`;
    return this.http.get<Course>(url).pipe(
      tap(_ => console.log(`fetched course id=${id}`)),
      catchError(this.handleError<Course>(`getHero id=${id}`))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }


  deleteCourse(course: Course ): Observable<Course> {
    // const id = typeof course === 'number' ? course : course.id;
    const url = `${this.cousesUrl}/${course.id}`;

    return this.http.delete<Course>(url, this.httpOptions).pipe(
      tap(_ => console.log(`deleted Course id=${course.id}`)),
      catchError(this.handleError<Course>('deleteCourse'))
    );
  }

  saveCourse(course: Course): Observable<Course> {
    course.id = 999;
    return this.http.post<Course>(this.cousesUrl, course, this.httpOptions).pipe(
      tap((newHero: Course) => console.log(`added course w/ id=${newHero.id}`)),
      catchError(this.handleError<Course>('addCOurse'))
    );
  }

  updateCourse(course: Course): Observable<Course> {
    return this.http.put(this.cousesUrl, course, this.httpOptions).pipe(
      tap(_ => console.log(`updated course id=${course.id}`)),
      catchError(this.handleError<any>('updatecourse'))
    );
  }
}


    // // return COURSES.find(course => course.id === id)
    // saveCourse(newCourse) {
    //     newCourse.id = 999
    //     // courses.push(newCourse)
    // }
// const courses: Course[] = [
//     {
//         id: 1,
//         name: 'Angular',
//         date: new Date('10/10/2010'),
//         time: '9:00 am',
//         duration: 1,
//         price: 1000,
//         imageUrl: '/assets/images/angular.png',
//         location: {
//             trainingRoom: 'Room1',
//             building: 'building1',
//             city: 'city1'
//         }
//     },
//     {
//         id: 2,
//         name: 'React',
//         date: new Date('4/15/2015'),
//         time: '9:00 am',
//         price: 950.00,
//         imageUrl: '/assets/images/react.png',
//         onlineUrl: 'http://www.qwertasasa.com'
//     },
//     {
//         id: 3,
//         name: 'Java',
//         date: new Date('5/4/2037'),
//         time: '9:00 am',
//         price: 759.00,
//         imageUrl: '/assets/images/java.png',
//         location: {
//             trainingRoom: 'Room2',
//             city: 'city2',
//             building: 'building2'
//         }
//     },
//     {
//         id: 4,
//         name: 'Oracle',
//         date: new Date('6/14/2033'),
//         time: '8:00 am',
//         price: 800.00,
//         imageUrl: '/assets/images/oracle.png',
//         location: {
//             trainingRoom: 'Room1',
//             city: 'city1',
//             building: 'building1'
//         }
//     },
//     {
//         id: 5,
//         name: 'Spring',
//         date: new Date('12/12/2025'),
//         time: '9:00 am',
//         price: 400.00,
//         imageUrl: '/assets/images/spring.png',
//         location: {
//             trainingRoom: 'Room2',
//             city: 'city2',
//             building: 'building1'
//         },
//     }
// ]

// // private _url: string = "/assets/courses.json"
// // constructor(private http: HttpClient) {
// // }

// // getAllCourses(): Observable<Course[]> {
// //     return this.http.get<Course[]>(courses);
// // }

// // getCourseById(id: number): Observable<Course> {
// //     const url = `${this._url}/${id}`;
// //     return this.http.get<Course>(url).pipe(
// //         tap(_ => console.log(`fetched course id=${id}`)),
// //         catchError(this.handleError<Course>(`getHero id=${id}`))
// //     );
// // }
// // private handleError<T>(operation = 'operation', result?: T) {
// //     return (error: any): Observable<T> => {
// //         console.error(error); // log to console instead
// //         console.log(`${operation} failed: ${error.message}`);
// //          return of(result as T);
// //     };
// // }


// // // return COURSES.find(course => course.id === id)
// // saveCourse(newCourse) {
// //     newCourse.id = 999
// //     // courses.push(newCourse)
// // }