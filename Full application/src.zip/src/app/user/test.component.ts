import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  template: `<h1>User Module</h1>`,
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class TestComponent  {

  constructor()
  {}
}
