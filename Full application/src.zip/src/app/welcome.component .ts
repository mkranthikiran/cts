import { Component } from '@angular/core';

@Component({
  selector: 'welcome',
  template: "<div>Welcome Template </div>",
})
export class WelcomeComponent {
}
