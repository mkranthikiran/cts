import { Component } from '@angular/core';
import { from, Observable, of, pipe, range } from 'rxjs';
import { count, filter, map, max } from 'rxjs/operators';


@Component({
  selector: 'observable',
  template: `<observable></observable>`,
})
export class ObservableComponent {

   nums = of(1, 2, 3, 4, 5);

   constructor(){

    let numbers = [3,9,7];
    let source = from(numbers).pipe(map(value => {return 2*value;})).subscribe(value => {console.log(value);})


    this. nums.subscribe(x => console.log(x));
   
    // console.log("-----------------------");
 

    this. nums.pipe(
                    filter((n: number) => n % 2 !== 0),
                    map(n => n * n)
                    )
                    .subscribe(x => console.log(x));

    //   console.log("-----------------------");

    const numbers1 = range(1, 7);
    const result = numbers1.pipe(count(i => i % 2 === 1));
    result.subscribe(x => console.log(x));

    of(5, 4, 7, 2, 8).pipe(
      max(),
    )
    .subscribe(x => console.log(x));

   } 
}
