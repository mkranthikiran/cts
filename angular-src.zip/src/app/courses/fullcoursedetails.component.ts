import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {Course} from '../shared/course.model'
import {CourseService} from '../shared/course.service'

@Component({
  selector: 'course-details',
  templateUrl : './fullcoursedetails.component.html',
})

export class FullCourseDetailsComponent implements OnInit {

  course : Course

  constructor(private courseService : CourseService,private activatedRoute : ActivatedRoute){}

  ngOnInit() {
     this.course =  this.courseService.getCourseById(+this.activatedRoute.snapshot.params['id']);
  }

}