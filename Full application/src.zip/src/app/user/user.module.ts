import {  CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {UserRoutingModule} from './user-routing.module'
import {UserLoginComponent} from './user.login.component'
import {FormsModule} from '@angular/forms'
import {ReactiveFormsModule} from '@angular/forms' 
import { TestComponent } from './test.component';
import { UserProfileComponent } from './user.profile.component';


@NgModule({
  declarations: [UserLoginComponent,TestComponent,UserProfileComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,ReactiveFormsModule  ],
  providers : [],
  exports: []
 })
export class UserModule { }
