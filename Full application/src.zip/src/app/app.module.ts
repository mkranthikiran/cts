import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { CourseComponent } from './app.component';
import { WelcomeComponent } from './welcome.component '
import { PracticeComponent } from './practice.component';
import { CourseListComponent } from './courses/course-list.component'
import { AllCourseListComponent } from './courses/allcourse-list.component'
import { NavBarComponent } from './navigation/navbar.component'
import { CourseService } from './shared/course.service'
import { FullCourseDetailsComponent } from './courses/fullcoursedetails.component';
import { ErrorComponent } from './error/error.component';
import { CourseRouterActivatorService } from './shared/course.activate.router';
import { CreateCourseComponent } from './courses/createcourse.component';
import { FormsModule } from '@angular/forms';
import { UserAuthenticateService } from './user/user.authenticate.service';
import { InMemoryDataService } from './shared/inmemory.service';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { JsonComponent } from './Jsonplaceholder/json.component';
import { JsonService } from './Jsonplaceholder/jsonplaceholder.service';
import { ObservableComponent } from './observableex.component';

@NgModule({
  declarations: [
    CourseComponent, CourseListComponent, AllCourseListComponent,
    NavBarComponent, WelcomeComponent, PracticeComponent, FullCourseDetailsComponent, ErrorComponent,
    CreateCourseComponent,JsonComponent,ObservableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(InMemoryDataService, { dataEncapsulation: false })
  ],
  providers: [CourseService, CourseRouterActivatorService,UserAuthenticateService,JsonService],
  bootstrap: [CourseComponent]
})
export class AppModule { }
