import { Component } from '@angular/core';

@Component({
  selector: 'practice',
  template: `<div>
                  <h1>HelloWorld</h1> 
                  <img src="assets/images/basic-shield.png"/> 
                  <div>
                  <h2  class="text-success">CTS</h2>
                  <h2 [class]="textSuccess">CTS</h2>
                  <h2 [class]='textSuccess' class="text-special" > CTS</h2>
                  <h2 [class.text-danger]='hasError'>Error</h2>
                  <h2 [ngClass]='messageStyle'>special</h2>
                  </div>
                  <div>
                  <h2  [style.color]='"Blue"'>CTS </h2>                  
                  </div>
                  <div>
                    <input type="text" name="name" value="CTS" [disabled]=isDisable/>
                  </div>
              </div>`,
  styles:[`
            .text-success{color:green;}
            .text-danger{color:red;}
            .text-special{font-style:italic;} 
 `]
 })

export class PracticeComponent {
   textSuccess = "text-success"
   hasError = false;
   isSpecial = true;
   messageStyle = {  "text-success":!this.hasError,
                     "text-danger": this.hasError,
                     "text-special": this.isSpecial
                  };
  isDisable = true
}
