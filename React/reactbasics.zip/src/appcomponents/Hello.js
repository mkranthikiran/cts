import React from 'react'

const Hello = () => {
    //with JSX
      return (
        <div>
                <div className='dummyClass'>
                       <h1>Hello With JSX </h1>
                </div>
        </div>
       )
    // return React.createElement('div',null,React.createElement('h1', {id : 'color.red'}, 'Hello  from React'))

    //Without Jsx
      // return React.createElement(
      //   'div',
      //   {id: 'hello', className: 'dummyClass'},
      //   React.createElement('h1', null, 'Hello ')
      // )
    }
    
    export default Hello
    