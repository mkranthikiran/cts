import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { Course } from '../shared/course.model';
import {CourseService} from '../shared/course.service'

@Component({
  templateUrl: './create.course.component.html',
  styles : ['em{float:right; color: #E05c65; padding-left-10px;}']
})
export class CreateCourseComponent {
    isDirty : boolean = true;
  constructor(private router : Router,private courseService : CourseService){}
  
  saveCourse(newCourse){
    this.courseService.saveCourse(newCourse).subscribe((course)=>  console.log(console));
    this.router.navigate(['allcourses']);
  }
  cancel(){
    this.router.navigate(['/allcourses']);
  }
}

  // this.courseService.saveCourse(newCourse)
    // this.isDirty  = false;
    // this.router.navigate(['/allcourses'])