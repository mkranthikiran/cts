package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Message;
import com.cts.service.MessageService;

//mark class as Controller
@RestController
public class MessageController {
	// autowire the MessageService class
	@Autowired
	MessageService meesageService;

	public MessageController() {
	}
	// creating a get mapping that retrieves all the messages detail from the
	// database
	@GetMapping("/messages")
	private List<Message> getAllMessage() {
		System.out.println("All Messages******");
		return meesageService.getAllMessage();
	}

	// creating a get mapping that retrieves the detail of a specific message
	@GetMapping("/messages/{messageid}")
	private Message getMessage(@PathVariable("messageid") long messageid) {
		return meesageService.getMessageById(messageid);
	}

	// creating a delete mapping that deletes a specified message
	@DeleteMapping("/messages/{messageid}")
	private void deleteMessage(@PathVariable("messageid") long messageid) {
		meesageService.delete(messageid);
	}

	// creating post mapping that post the message detail in the database
	@PostMapping("/messages")
	private long saveMessage(@RequestBody Message message) {
		meesageService.saveOrUpdate(message);
		return message.getId();
	}

	// creating put mapping that updates the message detail
	@PutMapping("/messages")
	private Message update(@RequestBody Message message) {
		meesageService.saveOrUpdate(message);
		return message;
	}
}
